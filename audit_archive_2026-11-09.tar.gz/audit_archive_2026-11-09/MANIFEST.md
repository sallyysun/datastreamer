# Audit archive, 2026-11-09 (branch bank-vff-study)

- **Base commit:** `33f51fde6078e61ef22b7f83b7fcecc4d14cf0b7` (`33f51fd`). All audit code changes are uncommitted; they
  are in `code/uncommitted_changes.patch` (tracked files, binary-safe) and `code/untracked_files.tar`
  (new files, listed in `code/untracked_files.txt`).
- **Code fingerprint** (sha256 of `git diff HEAD -- src experiments/*.cpp experiments/Makefile` plus
  the new headers and probe): `96f6727b67e98cf8`.
  - No file under `src/` or `experiments/*.cpp` was modified after the final runs began (14:28 UTC);
    the newest source mtime is 14:27:34.
  - The evaluation-time fingerprint `6b773adcbc4d6527` hashed the whole `git diff`, notes included,
    so it cannot be recomputed now that the notes have changed. The code fingerprint above
    replaces it.
- **Platform:** Linux x86_64, libstdc++, g++/clang++ 18, `-O2 -std=c++20`, Eigen in /usr/include/eigen3,
  DataSketches submodule `c2f89d7`.

## Restore
```bash
git checkout 33f51fd -b audit-restore      # or: stay on bank-vff-study at 33f51fd
git apply code/uncommitted_changes.patch
tar -xf code/untracked_files.tar
cp -r results/final/* experiments/results/   # final frozen outputs
```

## Contents
| Directory | What | Seeds |
|---|---|---|
| `results/final/` | Frozen-configuration evaluation: main banks and VFF (`thesis_bank_final500/1999*`), regret (`bank_regret_42_final*`, family `bank_regret_family_42_final500*`), family bank (`family_bank_*42*`), tail bank (`tail_bank_*_42`), budget (`budget_*`), collected tables (`final_eval_2026-11-09.txt`) | 42–101; budget test 42–141, validation 1000–1039 |
| `results/dev/` | Development runs: staged diagnostics (`thesis_bank_diag_*`, `bank_regret_1_*`), VFF validation (`vff_common*`), retuning (`bank_tune_1*`) | 1–30 |
| `results/pre_audit/` | Pre-audit outputs, the "before" of the paired comparisons | 42–101 (`bank_tune_1*`: 1–30) |
| `results/pre_accounting/` | Budget sweep before the memory-accounting fix | budget seeds |
| `notes/` | `ew_marginals.md` (audit Parts I–III), `handoff_codex.md`, `budget_mpl.md` | |
| `code/*.sh`, `code/*.cpp` | Run scripts and standalone check programs (EW-marginal validation, Hermite start-up study, theory checks, regression, TSan race test, derivative check) | |

## Overwritten results (no paired before/after possible)
- `family_bank_switch_42*`, `family_bank_path_42*`: the pre-audit versions were not preserved.
  Shape-switch times before the audit are known only as the 60-seed medians in
  `thesis_bank_family.md`, so that comparison is aggregate only.
- `budget_paths*.csv`: overwritten by the accounting rerun and again by the final sweep. The
  pre-audit `budget_sweep.csv` is in `pre_audit/` and the pre-accounting one in `pre_accounting/`;
  mean recovery paths before the audit are lost.
- `bank_weights_paths_drift.csv` (input to `ch6_neff_optimum.png` panel c) and `bank_tune_42*` were
  not rerun. They are stale (pre-audit configuration), not overwritten.
- The own-density tuning on seeds 1–30 (`bank_tune_1*` own columns) was overwritten by the retune
  run, whose own columns used raw-trained arms. The pre-audit copy is in `pre_audit/`; neither
  version is valid for the final configuration (see Part III).

## Reproduce
See `notes/ew_marginals.md` §11 (Part I) and §20 (Part II); `code/final.sh` runs the whole
evaluation. Analysis:
`compare_diag.py`, `conclusions_diag.py`, `family_bank_table.py 42`, `tail_bank_table.py`,
`analyze_budget.py`, `compare_budget_accounting.py`.

## Checksums
See `SHA256SUMS` (every file in this archive).
