// Validation of EwMarginal against the exact exponentially weighted ECDF (truncated at weight < 1e-14).
#include <cmath>
#include <cstdio>
#include <deque>
#include <random>
#include "dependence/ew_marginal.hpp"
struct Exact { double kap; std::deque<double> xs; size_t cap;
  double u(double x) const { double B=0,W=0,w=kap; for (auto it=xs.rbegin(); it!=xs.rend(); ++it){ W+=w; if(*it<x) B+=w; w*=kap; } return (B+1)/(W+2); } };
int main(){
  struct Case { const char* name; double neff; long n; int kind; };
  // kind 0: N(0,1); 1: heavy ties (values on a 7-point grid); 2: margin jumps every 50k; 3: Cauchy (extremes)
  Case cs[] = {{"normal 500",500,400000,0},{"normal 1999",1999,1000000,0},{"ties 500",500,200000,1},{"jumps 500",500,400000,2},
               {"cauchy 500",500,200000,3},{"normal cum",0,200000,0}};
  for (const auto& c : cs) for (double eps : {0.005}) {
    EwMarginal m(c.neff, eps); double kap = c.neff>1 ? (c.neff-1)/(c.neff+1) : 1.0;
    size_t cap = c.neff>1 ? size_t(std::log(1e-14)/std::log(kap)) : 400000;
    Exact ex{kap,{},cap}; std::mt19937_64 g(11); std::normal_distribution<double> N; std::cauchy_distribution<double> C;
    double maxe=0, se=0; long k=0; size_t maxt=0; double maxe_ext=0;
    for (long t=0;t<c.n;t++){
      double x = c.kind==1 ? std::round(N(g)*1.5) : c.kind==3 ? C(g) : N(g) + (c.kind==2 ? 3.0*((t/50000)%2) : 0.0);
      bool check = (t % 997 == 0) && t > 50;
      double ue = check ? ex.u(x) : 0;
      // extreme queries: far below / above everything, before inserting
      if (check) { double lo = m.cdf(-1e300), hi = m.cdf(1e300); maxe_ext = std::max({maxe_ext, std::fabs(lo), std::fabs(hi-1)}); }
      double u = m.transform(x);
      if (check){ double e=std::fabs(u-ue); maxe=std::max(maxe,e); se+=e*e; ++k; }
      ex.xs.push_back(x); if (ex.xs.size()>cap) ex.xs.pop_front();
      maxt = std::max(maxt, m.tuples());
      if (!std::isfinite(u) || u<=0 || u>=1) { printf("  BAD u=%g at t=%ld\n",u,t); break; }
    }
    printf("%-12s n=%8ld: max|u-exact| %.4f (eps %.3f)  rmse %.5f  extreme-query err %.1e  max tuples %4zu, tuples at end %4zu\n",
           c.name,c.n,maxe,eps,std::sqrt(se/k),maxe_ext,maxt,m.tuples());
  }
}
