#include <cmath>
#include <cstdio>
#include <random>
// m_n with fixed lambda and its recursive derivative vs a central finite difference
int main(){ std::mt19937 g(1); std::normal_distribution<double> N; std::vector<double> p(3000); for(auto&x:p) x=N(g)+0.5;
  for (double lam : {0.95, 0.99, 0.999}) {
    auto run=[&](double l, double* dm_out){ double m=0,w=0,dm=0,dw=0; for(double x:p){ double wo=w; w=l*w+1; dw=l*dw+wo; double e=x-m; dm=dm*(1-1/w)-e*dw/(w*w); m+=e/w; } if(dm_out)*dm_out=dm; return m; };
    double dm; run(lam,&dm); double h=1e-6; double fd=(run(lam+h,nullptr)-run(lam-h,nullptr))/(2*h);
    printf("lambda %.3f: recursive dm/dlambda %.6f, finite difference %.6f\n",lam,dm,fd); } }
