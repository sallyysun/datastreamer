#include <cmath>
#include <cstdio>
#include <random>
#include <vector>
#include <Eigen/Dense>
#include "estimators/dependence/hermiter.hpp"
#include "estimators/dependence/xiao_spearman.hpp"
#include "estimators/dependence/ew_marginal.hpp"
#include "estimators/dependence/recursive_mpl.hpp"
using H=HermiteEstimator;
Eigen::VectorXd hf(double x,int N){ Eigen::VectorXd h(N+1); double g=std::exp(-0.5*x*x); h(0)=g/std::sqrt(std::sqrt(M_PI)); if(N>0) h(1)=std::sqrt(2.0)*x*h(0);
  for(int k=2;k<=N;k++) h(k)=x*std::sqrt(2.0/k)*h(k-1)-std::sqrt((k-1.0)/k)*h(k-2); return h; }
int main(){
  std::mt19937 g(5); std::normal_distribution<double> Nd; const int N=10; const int n=3000;
  std::vector<double> xs(n), ys(n); for(int i=0;i<n;i++){ xs[i]=Nd(g); ys[i]=0.6*xs[i]+0.8*Nd(g); }
  // (1) Hermite, normal-score inputs: A_n vs direct weighted sums
  struct V { const char* name; H::Config::Start st; double lam; };
  for (V v : {V{"Normalised lam=.001",H::Config::Start::Normalised,0.001}, V{"Normalised lam=.05",H::Config::Start::Normalised,0.05},
              V{"Literal lam=.001",H::Config::Start::Literal,0.001}, V{"cumulative",H::Config::Start::Normalised,0.0}}) {
    H::Config c{}; c.order=N; c.lambda=v.lam; c.normal_score_inputs=true; c.start=v.st; H e(c,"h");
    double maxd=0;
    for(int m=1;m<=n;m++){ e.update(xs[m-1],ys[m-1]);
      if (m==1||m==10||m==500||m==3000) {
        Eigen::MatrixXd A=Eigen::MatrixXd::Zero(N+1,N+1); double W=0;
        for(int i=1;i<=m;i++){ double w;
          if (v.lam==0) w=1; else if (v.st==H::Config::Start::Normalised) w=std::pow(1-v.lam,m-i);
          else w = (i==1) ? std::pow(1-v.lam,m-1) : v.lam*std::pow(1-v.lam,m-i);   // thesis 5.1.2 literal
          A+=w*hf(xs[i-1],N)*hf(ys[i-1],N).transpose(); W+=w; }
        if (v.st!=H::Config::Start::Literal || v.lam==0) A/=W;
        maxd=std::max(maxd,(A-e.coefficients()).cwiseAbs().maxCoeff()); } }
    printf("Hermite %-22s max|A_code - A_definition| = %.2e\n", v.name, maxd);
  }
  // first-observation weight at n=500, lambda_update=0.001
  printf("weight of X_1 at n=500 (update weight .001): literal %.3f, normalised %.5f (others' %.5f)\n",
         std::pow(0.999,499), std::pow(0.999,499)/((1-std::pow(0.999,500))/0.001), 1/((1-std::pow(0.999,500))/0.001));
  // (2) EwMarginal no forgetting, eps tiny == RankPit with an unbounded window, bit-exact
  { EwMarginal em(0.0,1e-12); RankPit rp(100000); int diff=0; for(int i=0;i<n;i++){ if (em.transform(xs[i])!=rp.transform(xs[i])) diff++; }
    printf("EwMarginal(no forgetting, eps->0) vs exact ranks (R+1)/(n+2): %d of %d differ\n",diff,n); }
  // (3) Xiao normal-score cut-points are probit(k/B): uniform u lands equiprobably
  { XiaoSpearmanEstimator x(XiaoSpearmanEstimator::Config{.bins=20,.lambda=0.0,.normal_score_inputs=true},"x");
    std::uniform_real_distribution<double> U(0,1); for(int i=0;i<200000;i++){ double u=U(g); x.update(RankPit::probit(u),RankPit::probit(U(g))); }
    printf("Xiao normal-score mode, independent uniforms: rho_hat = %+.4f (should be ~0), store %zu B\n",x.estimate(),x.store_bytes()); }
  // (4) RMPL normalised gain: with gain g the m-th gain equals g/(1-(1-g)^m)  (check via a frozen-information construction)
  { double gn=0.01, W=0; double maxd=0; for(int m=1;m<=2000;m++){ W=(1-gn)*W+gn; maxd=std::max(maxd,std::fabs(gn/W - gn/(1-std::pow(1-gn,m)))); }
    printf("RMPL normalised gain recursion vs closed form g/(1-(1-g)^m): max diff %.1e\n",maxd); }
}
