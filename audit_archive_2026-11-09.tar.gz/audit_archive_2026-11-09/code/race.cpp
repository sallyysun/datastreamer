#include <cstdio>
#include <thread>
#include <vector>
#include "estimators/copula_family.hpp"
int main(){
  double ref[3][5]; double nus[3]={3,4,8};
  for(int i=0;i<3;i++) for(int j=0;j<5;j++) ref[i][j]=0; 
  // threaded first (cold cache), then compare with a fresh single-threaded process value computed after
  std::vector<std::thread> th; double out[8][3][5];
  for(int w=0;w<8;w++) th.emplace_back([&,w]{ for(int rep=0;rep<50;rep++) for(int i=0;i<3;i++) for(int j=0;j<5;j++) out[w][i][j]=copula::spearman_from_param(copula::Family::StudentT,-0.8+0.4*j,nus[(i+w)%3]); });
  for(auto&t:th) t.join();
  int bad=0; for(int w=0;w<8;w++) for(int i=0;i<3;i++) for(int j=0;j<5;j++){ double r=copula::spearman_from_param(copula::Family::StudentT,-0.8+0.4*j,nus[(i+w)%3]); if(r!=out[w][i][j]) bad++; }
  printf("t-table: %d mismatches across 8 threads x 3 nu\n",bad);
}
