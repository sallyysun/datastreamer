#!/bin/bash
cd /home/user/datastreamer/experiments
run() { tag=$1; comps=$2; shift 2
  for f in gaussian clayton gumbel t; do env "$@" SEED_BASE=1 COPULA=$f COMPONENTS=$comps TAG=diag_$tag ./probe_thesis_bank 30 > /dev/null 2>&1 & done; wait; echo "$(date +%H:%M) $tag done"; }
reg() { tag=$1; shift
  for f in gaussian clayton gumbel t; do env "$@" COPULA=$f TAG=$tag ./probe_bank_regret 1 30 > /dev/null 2>&1 & done; wait; echo "$(date +%H:%M) regret $tag done"; }
F="BANK_ARM_INPUTS=raw HERMITE_START=normalised RMPL_START=normalised"
run F500r  xiao,hermite,mle BANK_MARGINAL=ew BANK_MARGINAL_NEFF=500  $F
run F1999r xiao,hermite,mle BANK_MARGINAL=ew BANK_MARGINAL_NEFF=1999 $F
run F500s  xiao,hermite     BANK_MARGINAL=ew BANK_MARGINAL_NEFF=500  BANK_ARM_INPUTS=shared HERMITE_START=normalised
reg R0     BANK_MARGINAL=window BANK_ARM_INPUTS=composite HERMITE_START=legacy RMPL_START=max
reg F500r  BANK_MARGINAL=ew BANK_MARGINAL_NEFF=500 $F
reg F1999r BANK_MARGINAL=ew BANK_MARGINAL_NEFF=1999 $F
echo ALLDONE
