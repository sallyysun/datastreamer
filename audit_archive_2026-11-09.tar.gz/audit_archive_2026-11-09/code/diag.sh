#!/bin/bash
# Paired diagnostics, seeds 1-30, one factor at a time (notes/studies/ew_marginals.md).
cd /home/user/datastreamer/experiments
run() {  # tag comps env...
  tag=$1; comps=$2; shift 2
  for f in gaussian clayton gumbel t; do
    env "$@" SEED_BASE=1 COPULA=$f COMPONENTS=$comps TAG=diag_$tag ./probe_thesis_bank 30 > /dev/null 2>&1 &
  done; wait; echo "$(date +%H:%M) $tag done"
}
B="BANK_MARGINAL=window BANK_ARM_INPUTS=composite HERMITE_START=legacy RMPL_START=max"
run R0  xiao,hermite,mle $B
run M1  xiao,hermite,mle BANK_MARGINAL=ew BANK_MARGINAL_NEFF=500  BANK_ARM_INPUTS=composite HERMITE_START=legacy RMPL_START=max
run M2  xiao,hermite,mle BANK_MARGINAL=ew BANK_MARGINAL_NEFF=1999 BANK_ARM_INPUTS=composite HERMITE_START=legacy RMPL_START=max
run H1  hermite BANK_MARGINAL=window BANK_ARM_INPUTS=composite HERMITE_START=runningmean
run H2  hermite BANK_MARGINAL=window BANK_ARM_INPUTS=composite HERMITE_START=literal
run H3  hermite BANK_MARGINAL=window BANK_ARM_INPUTS=composite HERMITE_START=normalised
run H4  hermite BANK_MARGINAL=window BANK_ARM_INPUTS=composite HERMITE_START=normalised HERMITE_MOMENTS=predictive
run Rn  mle BANK_MARGINAL=window RMPL_START=normalised
run Rc  mle BANK_MARGINAL=window RMPL_START=constant
run Ps  xiao,hermite BANK_MARGINAL=window BANK_ARM_INPUTS=shared HERMITE_START=normalised
run Pr  xiao,hermite BANK_MARGINAL=window BANK_ARM_INPUTS=raw    HERMITE_START=normalised
echo ALLDONE
