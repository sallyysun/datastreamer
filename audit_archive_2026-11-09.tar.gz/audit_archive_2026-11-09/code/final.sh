#!/bin/bash
# Final evaluation, frozen configuration 6b773adcbc4d6527. Seeds 42-101 (budget: test 42-141, val 1000-1039).
cd /home/user/datastreamer/experiments
par4() { for f in gaussian clayton gumbel t; do env "$@" COPULA=$f & done; wait; }
for N in 500 1999; do
  for f in gaussian clayton gumbel t; do BANK_MARGINAL_NEFF=$N SEED_BASE=42 COPULA=$f COMPONENTS=xiao,hermite,mle TAG=final$N ./probe_thesis_bank 60 >/dev/null 2>&1 & done; wait
  echo "$(date +%H:%M) thesis_bank N=$N"
  for f in gaussian clayton gumbel t; do BANK_MARGINAL_NEFF=$N COPULA=$f TAG=final$N ./probe_bank_regret 42 60 >/dev/null 2>&1 & done; wait
  echo "$(date +%H:%M) regret N=$N"
done
for f in gaussian clayton gumbel t; do COPULA=$f TAG=final500 ./probe_bank_regret 42 60 family >/dev/null 2>&1 & done; wait
echo "$(date +%H:%M) family regret"
(for c in gaussian clayton gumbel t; do COPULA=$c ./probe_family_bank 42 60 >/dev/null 2>&1 & done; wait) 
(for c in gauss2t clayton2gumbel gauss2clayton; do COPULA=$c ./probe_family_bank 42 60 >/dev/null 2>&1 & done; wait)
echo "$(date +%H:%M) family bank"
(for r in gauss2clayton clayton2gumbel gauss2t; do ./probe_tail_bank $r 42 60 >/dev/null 2>&1 & done; wait)
(for r in mix gaussian; do ./probe_tail_bank $r 42 60 >/dev/null 2>&1 & done; wait)
echo "$(date +%H:%M) tail bank"
./probe_budget sweep 100 40 >/dev/null 2>&1; ./probe_budget time >/dev/null 2>&1
echo "$(date +%H:%M) budget"
echo ALLDONE
