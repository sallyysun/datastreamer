#include <cmath>
#include <cstdio>
#include <random>
#include <string>
#include <vector>
#include "estimators/dependence/hermiter.hpp"
using H = HermiteEstimator;
int main(){
  const int T=5000, SEEDS=200; const double rho=0.6, rs=6/M_PI*std::asin(rho/2);
  const int edges[] = {1,50,200,1000,5000};
  struct V { std::string name; bool legacy; H::Config::Start st; bool ns; bool pred; double loc, scale; };
  std::vector<V> vs = {
    {"legacy (old code)",          true,  H::Config::Start::RunningMean, false,false,0,1},
    {"running mean max(l,1/m)",    false, H::Config::Start::RunningMean, true, false,0,1},
    {"Ch5 literal a1=h(X1)",       false, H::Config::Start::Literal,     true, false,0,1},
    {"normalised Q/W",             false, H::Config::Start::Normalised,  true, false,0,1},
    {"raw N(5,.01^2): current",    false, H::Config::Start::Normalised,  false,false,5,0.01},
    {"raw N(5,.01^2): predictive", false, H::Config::Start::Normalised,  false,true, 5,0.01},
    {"raw N(5,.01^2): legacy",     true,  H::Config::Start::RunningMean, false,false,5,0.01}};
  printf("Gaussian copula rho_S=%.3f constant, order 10, %d seeds; RMSE x1000 by window of ticks; clamp%% = |rho|>=1\n",rs,SEEDS);
  for (double lam : {0.05, 0.01, 0.001}) {
    printf("\nupdate weight %.3f (N_eff %.0f)\n%-30s %9s %9s %9s %9s %7s\n",lam,(2-lam)/lam,"variant","[1,50)","[50,200)","[200,1k)","[1k,5k)","clamp%");
    for (const auto& v : vs) {
      double se[4]={0}; long cnt[4]={0}; long clamp=0, tot=0;
      for (int s=0;s<SEEDS;s++){
        H::Config c{}; c.order=10; c.lambda=lam; c.burn_in=0; c.legacy=v.legacy; c.start=v.st; c.normal_score_inputs=v.ns; c.predictive_moments=v.pred;
        H e(c,"h"); std::mt19937 g(1000+s); std::normal_distribution<double> N;
        for (int t=1;t<=T;t++){
          const double r = e.estimate();   // prediction before the update, as a bank scores it
          if (t>1 && e.ready()) { int w=0; while(w<3 && t>=edges[w+1]) w++; se[w]+=(r-rs)*(r-rs); cnt[w]++; tot++; if (std::fabs(r)>=0.999999) clamp++; }
          double a=N(g), b=rho*a+std::sqrt(1-rho*rho)*N(g);
          e.update(v.loc+v.scale*a, v.loc+v.scale*b);
        }
      }
      printf("%-30s",v.name.c_str()); for(int w=0;w<4;w++) printf(" %9.1f", cnt[w]? 1000*std::sqrt(se[w]/cnt[w]) : NAN); printf(" %7.2f\n",100.0*clamp/tot);
    }
  }
}
