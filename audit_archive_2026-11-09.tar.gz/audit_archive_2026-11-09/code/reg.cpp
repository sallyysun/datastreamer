#include <cmath>
#include <cstdio>
#include <memory>
#include <random>
#include <vector>
#include "estimators/dependence/hermiter.hpp"
#include "estimators/dependence/recursive_mpl.hpp"
#include "estimators/dependence/xiao_spearman.hpp"
#ifdef NEWCODE
#include "estimators/dependence/ew_marginal.hpp"
#endif
using X=XiaoSpearmanEstimator; using H=HermiteEstimator; using M=RecursiveMPL;
int main(){
  std::vector<std::unique_ptr<DependenceEstimator>> es;
  es.emplace_back(new X(X::Config{.bins=20,.lambda=0.98,.calibration=100},"x1"));
  es.emplace_back(new X(X::Config{.bins=20,.window=300,.calibration=100},"x2"));
  es.emplace_back(new X(X::Config{.bins=30},"x3"));
#ifdef NEWCODE
  { H::Config c{}; c.order=10; c.lambda=0.01; c.burn_in=50; c.legacy=true; es.emplace_back(new H(c,"h1")); }
  { H::Config c{}; c.order=20; c.burn_in=100; c.legacy=true; es.emplace_back(new H(c,"h2")); }
  { H::Config c{}; c.order=10; c.lambda=0.001; c.burn_in=50; c.legacy=true; es.emplace_back(new H(c,"h3")); }
#else
  es.emplace_back(new H(H::Config{.order=10,.lambda=0.01,.burn_in=50},"h1"));
  es.emplace_back(new H(H::Config{.order=20},"h2"));
  es.emplace_back(new H(H::Config{.order=10,.lambda=0.001,.burn_in=50},"h3"));
#endif
  { M::Config c{}; c.kll_k=64; c.startup=false; es.emplace_back(new M(c,"m1")); }
  { M::Config c{}; c.margin=M::Margin::ExactNormal; c.startup=true;
#ifdef NEWCODE
    c.startup_normalised=false;
#endif
    es.emplace_back(new M(c,"m2")); }
  std::mt19937 g(7); std::normal_distribution<double> N; double h[16]={0};
  for(int t=0;t<5000;t++){ double a=N(g),b=N(g),y=0.7*a+0.71*b;
    for(size_t k=0;k<es.size();k++){ es[k]->update(a,y); h[k]=h[k]*1.0000001+es[k]->estimate(); } }
  for(size_t k=0;k<es.size();k++) printf("%s %.17g\n",es[k]->name(),h[k]);
}
